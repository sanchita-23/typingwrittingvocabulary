test("Typing Speed Test WPM Calculation", () => {
    const typedText = "The quick brown fox";
    const prompt = "The quick brown fox jumps over the lazy dog.";
    const timeTaken = 30; // seconds
    const wordsTyped = typedText.trim().split(/\s+/).length;
    const wpm = ((wordsTyped / timeTaken) * 60).toFixed(2);
    expect(wpm).toBe("8.00");
  });
  