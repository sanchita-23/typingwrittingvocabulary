function toggleSidebar(sidebarId) {
  const sidebar = document.getElementById(sidebarId);
  if (sidebar.style.display === "block") {
    sidebar.style.display = "none";
  } else {
    sidebar.style.display = "block";
  }
}
document.addEventListener('DOMContentLoaded', () => {
  // Highlight the selected dropdown item and show the corresponding section
  document.querySelectorAll('.dropdown-item').forEach(item => {
    item.addEventListener('click', function(event) {
      event.preventDefault(); // Prevent default anchor behavior

      // Hide all sections
      document.querySelectorAll('.content section').forEach(section => {
        section.classList.remove('active');
      });

      // Show the selected section
      const targetSection = this.getAttribute('href').substring(1); // Get section ID from the href (remove '#')
      document.getElementById(targetSection).classList.add('active');

      // Highlight the selected menu item
      document.querySelectorAll('.dropdown-item').forEach(link => {
        link.style.color = ''; // Reset color for all items
      });
      this.style.color = 'blue'; // Highlight the clicked item
    });
  });


  // Optionally, show the "Add a Project" section by default
  document.querySelector('#add-project').classList.add('active');

  // Set the active class on the navbar link based on the current URL
  const navbarLinks = document.querySelectorAll('.navbar a');
  navbarLinks.forEach(link => {
    if (link.href === window.location.href) {
      link.classList.add('active'); // Add active class to the current link
    }
  });

  // Delete project functionality
  document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', function() {
      const projectItem = this.closest('.project-item'); // Get the closest <li> element
      const projectId = projectItem.getAttribute('data-id'); // Get the ID

      // Confirm deletion
      if (confirm('Are you sure you want to delete this project?')) {
        // Remove the item from the UI
        projectItem.remove();

        // Optionally, send a request to the server to delete the item from the database
        const isOngoing = projectItem.closest('#ongoing-projects') !== null;
        fetch(isOngoing ? `/delete-ongoing-project/${projectId}` : `/delete-project/${projectId}`, {
          method: 'DELETE'
        }).then(response => {
          if (response.ok) {
            console.log('Project deleted successfully');
          } else {
            console.error('Failed to delete project');
          }
        });
      }
    });
  });

  // Edit project functionality
  const editModal = document.getElementById('edit-modal');
  const projectIdInput = document.getElementById('project-id');
  const projectNameInput = document.getElementById('project-name');
  const clientNameInput = document.getElementById('client-name');
  const projectStatusInput = document.getElementById('project-status');

  document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', function() {
      const projectItem = this.closest('.project-item'); // Get the closest <li> element
      const projectInfo = projectItem.querySelector('.project-info');

      // Populate the modal inputs
      projectIdInput.value = projectItem.getAttribute('data-id'); // Store project ID
      projectNameInput.value = projectInfo.querySelector('h3').innerText; // Project Name
      clientNameInput.value = projectInfo.querySelector('p').innerText.replace('Client: ', ''); // Client Name
      projectStatusInput.value = projectInfo.querySelectorAll('p')[1].innerText.replace('Status: ', ''); // Status

      // Show the modal
      editModal.style.display = 'block';
    });
  });

  // Close the modal when the close button is clicked
  document.querySelector('.close-btn').addEventListener('click', function() {
    editModal.style.display = 'none';
  });

  // Save functionality for editing
  document.getElementById('save-btn').addEventListener('click', function() {
    const projectId = projectIdInput.value;
    const projectItem = document.querySelector(`.project-item[data-id="${projectId}"]`);
    const projectInfo = projectItem.querySelector('.project-info');

    // Update the project info
    projectInfo.querySelector('h3').innerText = projectNameInput.value; // Project Name
    projectInfo.querySelector('p').innerText = 'Client: ' + clientNameInput.value; // Client Name
    projectInfo.querySelectorAll('p')[1].innerText = 'Status: ' + projectStatusInput.value; // Status

    // Hide the modal after saving
 editModal.style.display = 'none';
  });



  
  // Handle task item selection (optional)
  document.querySelectorAll('.task-item').forEach(item => {
    item.addEventListener('click', function() {
      // Remove 'selected' class from all task items
      document.querySelectorAll('.task-item').forEach(i => i.classList.remove('selected'));
      
      // Add 'selected' class to the clicked task item
      this.classList.add('selected');
    });
  });
});